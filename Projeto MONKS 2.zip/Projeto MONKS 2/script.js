//menu dropdown e do botão de fechar
const categoriesButton = document.querySelector('.categories-button');
const dropdownMenu = document.querySelector('#dropdown-menu');
const closeButton = document.querySelector('.close-button');


categoriesButton.addEventListener('click', function() {

    dropdownMenu.style.display = 'flex';
});

closeButton.addEventListener('click', function() {

    dropdownMenu.style.display = 'none';
});


// função para gerar um número aleatório entre 1 e 10
function generateRandomNumber() {
    return Math.floor(Math.random() * 10) + 1;
}

function startSecurityVerification() {
    var number1 = generateRandomNumber();
    var number2 = generateRandomNumber();

    document.getElementById("number1").textContent = number1;
    document.getElementById("number2").textContent = number2;

    var correctAnswer = number1 + number2;

    document.getElementById('verify-button').addEventListener('click', function(event) {
        event.preventDefault();

        var userResult = document.getElementById('user-result').value;

        if (parseInt(userResult) === correctAnswer) {
            document.getElementById('feedback').innerText = "Verificação bem-sucedida! Redirecionando...";
            window.location.href = "https://EuTenteiDesculpaT~T.com";
        } else {
            document.getElementById('feedback').innerText = "Resultado incorreto. Tente novamente.";
        }
    });
}
document.addEventListener('DOMContentLoaded', startSecurityVerification);